/// <reference path="./asar.d.ts" />
/// <reference path="./getmac.d.ts" />
